/*Create Database Food_To_Door1;
use Food_To_Door1; */

create table RestaurantEmployee(
EmloyeeID int,
Fname varchar (10) not null,
Lname varchar(10) not null,
Email varchar (40) not null,
password_ varchar (15) not null,
Username varchar (20) not null,
PRIMARY KEY (EmloyeeID)
);

INSERT INTO RestaurantEmployee(EmloyeeID,Fname,Lname,Email,password_,Username) VALUES
 (5000,'Narjis','Al-Jumaia','Narjis@gmail.com','Emp@Narjis','Narjis_H'),
(5001,'Ghaidaa','Alotaibi','Ghaidaas@gmail.com','Emp@Ghaidaa','Ghaidaa_A'),
(5002,'Layan','Alghamdi','Layan@gmail.com','Emp@Layan','Layan_B'),
(5003,'Fatimah','Al-Nasser','Fatimah@gmail.com','Emp@Fatimah','Fatimah_Z'),
(5004,'Zainab','Al-Nasser','Zainab@gmail.com','Emp@Zainab','Zainab_L');



Create table Restaurants(
Restaurant_ID int,
Restaurant_Name varchar (20) not null,
primary key (Restaurant_ID)
); 

INSERT INTO Restaurants (Restaurant_ID,Restaurant_Name) VALUES
(7000,'Tawat Rahimah'),(7001,'Shawmi');



Create table Menu(
Restaurant_ID int,
Product_ID int,
Category varchar (30),
Product_Name varchar (30),
Price int,
primary key(Product_ID),
foreign key (Restaurant_ID) references Restaurants (Restaurant_ID)
);


INSERT INTO Menu (Restaurant_ID,Product_ID,Category,Product_Name,Price) VALUES
(7000,1,'Sandwiches','Chicken Shawarma',8),
(7000,2,'Sandwiches','Falafel',6),
(7000,3,'Sandwiches','Chicken burger',8),
(7000,4,'Sandwiches','Chicken kabab',14),
(7000,5,'Drinks','Espresso',7),
(7000,6,'Drinks','Cappuccino',8),
(7000,7,'Drinks','Americano',7),
(7000,8,'Drinks','Hot chocolate',8),
(7000,9,'Drinks','Latte',8),
(7000,10,'Drinks','Lemon mojito',4),
(7000,11,'Drinks','Strawberry mojito',14),
(7001,12,'Sandwiches','Club sandwich',8),
(7001,13,'Sandwiches','Omelette sandwich',4),
(7001,14,'Sandwiches','Halloumi',6),
(7001,15,'Salads','Green salad',5),
(7001,16,'Salads','Shaw salad',8),
(7001,17,'Deserts','Cookies',6),
(7001,18,'Deserts','Mango sandwich',6),
(7001,19,'Cold drinks','Ice americano',10),
(7001,20,'Cold drinks','Ice mocha',15),
(7001,21,'Cold drinks','Orange juice',4),
(7001,22,'Cold drinks','Water',1),
(7001,23,'Hot drinks','Tea',3),
(7001,24,'Hot drinks','Cappuccino',12),
(7001,25,'Hot drinks','Espresso',6);


Create table Update_(
Employee_ID int ,
Product_ID int ,
Primary key(Employee_ID ,Product_ID),
foreign key (Employee_ID) references RestaurantEmployee (EmloyeeID),
foreign key (Product_ID) references Menu (Product_ID)
);


INSERT INTO Update_ (Employee_ID,Product_ID) VALUES 
(5000,1),
(5000,2),
(5000,3),
(5000,4),
(5000,5),
(5001,6),
(5001,7),
(5001,8),
(5001,9),
(5001,10),
(5002,11),
(5002,12),
(5002,13),
(5002,14),
(5002,15),
(5003,16),
(5003,17),
(5003,18),
(5003,19),
(5003,20),
(5004,21),
(5004,22),
(5004,23),
(5004,24),
(5004,25);


Create table Customer (
Customer_ID int ,
Fname varchar (10) not null,
Lname varchar(10) not null,
Email varchar (40)  not null,
Phone_num int not null,
Restaurant_ID int ,
Primary key (Customer_ID),
foreign key (Restaurant_ID) references Restaurants (Restaurant_ID)
);
 

INSERT INTO Customer (Customer_ID,Fname,Lname,Email,Phone_num,Restaurant_ID) VALUES
(1108754362,'Lama','Al Ahmed','Lama@gmail.com',0509871235,7000),
(1108794261,'Shahad','Alnasser','Shahad@gmail.com',0509675239,7000),
(1108794262,'Dana','Al Nasser','Dana@gmail.com',0509215264,7001),
(1108784147,'Alaa','Al Jumaia','Alaa@gmail.com',0544685739,7001),
(1108774130,'Ward','Alnasser','Ward@gmail.com',0567675239,7001);


Create table Location(
Customer_Location varchar(40),
Customer_ID int,
primary key(Customer_Location,Customer_ID),
foreign key (Customer_ID) references Customer (Customer_ID)
);

INSERT INTO Location (Customer_Location,Customer_ID) VALUES 
('Bulding A',1108754362),
('Bulding B',1108754362),
('Bulding C',1108794261),
('Bulding C',1108794262),
('Bulding B',1108784147),
('Bulding A',1108774130);


Create table payment( 
Customer_ID int  not null,
Card_Number int not null,
Name_on_Card varchar (40) not null,
CVV int  not null,
Primary key( Customer_ID, Card_Number),
foreign key (Customer_ID) references Customer (Customer_ID)
);



INSERT INTO payment (Customer_ID,Card_Number,Name_on_Card,CVV) VALUES
(1108754362,209876548,'LAMA AL AHMED',098),
(1108794261,609875749,'SHAHAD ALNASSER',765),
(1108794262,506879749,'DANA AL NASSER',432),
(1108784147,409865340,'ALAA AL JUMAIA',109),
(1108774130,609834689,'WARD ALNASSER',368);

Select * from payment;

Create table Orders ( 
Order_ID  int ,
Restaurant_ID int,
Customer_FName varchar(10),
Customer_LName varchar (10),  
Total_Price int , 
order_date date,
primary key (Order_ID),
foreign key (Restaurant_ID) references Restaurants (Restaurant_ID)
);


INSERT INTO Orders (Order_ID,Restaurant_ID,Customer_FName,Customer_LName,Total_Price,order_date) VALUES
(100,7000,'Lama','Al Ahmed',28,'2022-2-5'),
(101,7001,'Lama','Al Ahmed',5,'2022-2-5'),
(102,7000,'Shahad','Alnasser',8,'2022-2-8'),
(103,7000,'Dana','Al Nasser',8,'2022-2-10'),
(104,7001,'Alaa','Al Jumaia',18,'2022-3-16'),
(105,7001,'Ward','Alnasser',28,'2022-3-20');
