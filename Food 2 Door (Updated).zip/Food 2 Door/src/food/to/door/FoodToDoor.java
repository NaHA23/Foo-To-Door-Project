/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package food.to.door;

/**
 *
 * @author acer
 */
public class FoodToDoor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FoodToDoor_Logo s = new FoodToDoor_Logo();
        s.show();
    }
    
}
