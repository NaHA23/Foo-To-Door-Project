/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package food.to.door;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CustomerPayment extends javax.swing.JFrame {

   Connection con;
   
    public CustomerPayment() {
        
        try {
           initComponents();
           
            con= DriverManager.getConnection("jdbc:derby://localhost:1527/fo","fo","fo");
       } catch (SQLException ex) {
          
           JOptionPane.showMessageDialog(rootPane, ex.getMessage()); 
       }
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        goBack = new javax.swing.JButton();
        placeOrder = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Lable = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cardNumber = new javax.swing.JTextField();
        nameOnCard = new javax.swing.JTextField();
        JTextCVV = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        JTextID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextFirstName = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextLastName = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        goBack.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        goBack.setForeground(new java.awt.Color(0, 153, 153));
        goBack.setText("Go Back");
        goBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goBackActionPerformed(evt);
            }
        });
        jPanel1.add(goBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(272, 413, 143, -1));

        placeOrder.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        placeOrder.setForeground(new java.awt.Color(0, 153, 153));
        placeOrder.setText("Place Order");
        placeOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                placeOrderActionPerformed(evt);
            }
        });
        jPanel1.add(placeOrder, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 413, 143, -1));

        jLabel1.setFont(new java.awt.Font("Arabic Typesetting", 0, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 153));
        jLabel1.setText("Customer Payment");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 16, -1, -1));

        jLabel4.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 153));
        jLabel4.setText("Credit Card Number");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        Lable.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        Lable.setForeground(new java.awt.Color(0, 153, 153));
        Lable.setText("Name on Card");
        jPanel1.add(Lable, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 153));
        jLabel6.setText("CVV");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, -1, -1));

        cardNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cardNumberKeyTyped(evt);
            }
        });
        jPanel1.add(cardNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 120, -1));
        jPanel1.add(nameOnCard, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 240, 120, -1));

        JTextCVV.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTextCVVKeyTyped(evt);
            }
        });
        jPanel1.add(JTextCVV, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 290, 120, -1));

        jLabel2.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 153));
        jLabel2.setText("Customer ID ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 342, -1, -1));
        jPanel1.add(JTextID, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 340, 120, -1));

        jLabel5.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 153));
        jLabel5.setText("First Name");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jTextFirstName.setToolTipText("");
        jPanel1.add(jTextFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 120, -1));

        jLabel7.setFont(new java.awt.Font("Arabic Typesetting", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 153));
        jLabel7.setText("Last Name");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));
        jPanel1.add(jTextLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 120, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 486, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void goBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goBackActionPerformed
        Welcome Wel = new Welcome();
        Wel.show();
        dispose();
    }//GEN-LAST:event_goBackActionPerformed

    private void placeOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_placeOrderActionPerformed
//        java.util.Random r = new java.util.Random();
//       int start = 5007;
//       int end = 10000;
//       int ID = r.nextInt(end-start) + start;
        
        try {
           
           String FirstName = jTextFirstName.getText();
           String LastNAme = jTextLastName.getText();
           int CardNo = Integer.parseInt(cardNumber.getText());
           String NameOnCard = nameOnCard.getText();
           int CVV = Integer.parseInt(JTextCVV.getText());
           int CustomerID = Integer.parseInt(JTextID.getText());
           
           
           String sql ="INSERT INTO payment (Customer_ID , Card_Number , Name_on_Card , CVV  ) VALUES (?, ? , ?, ?)";
           PreparedStatement st = con.prepareStatement(sql);
           st.setInt(1, CardNo);
           st.setString(2, NameOnCard);
           st.setInt(3, CVV);
           st.setInt(4, CustomerID);
           
           
           int update = st.executeUpdate();
           
           if (update>0){
               
               
               JOptionPane.showMessageDialog(null, "Thank yor, Your Order On its way", "Order Placed",JOptionPane.INFORMATION_MESSAGE);
           }
           
       } catch (SQLException ex) {
           
          JOptionPane.showMessageDialog(rootPane, ex.getMessage());
       }
    }//GEN-LAST:event_placeOrderActionPerformed

    private void cardNumberKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cardNumberKeyTyped
        
        char Number = evt.getKeyChar();
        if(!(Character.isDigit(Number)) || (Number == KeyEvent.VK_BACK_SPACE) || (Number == KeyEvent.VK_DELETE))
        {
            evt.consume();
        }
    }//GEN-LAST:event_cardNumberKeyTyped

    private void JTextCVVKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTextCVVKeyTyped
        
        char Number = evt.getKeyChar();
        if(!(Character.isDigit(Number)) || (Number == KeyEvent.VK_BACK_SPACE) || (Number == KeyEvent.VK_DELETE))
        {
            evt.consume();
        }
    }//GEN-LAST:event_JTextCVVKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerPayment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerPayment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField JTextCVV;
    private javax.swing.JTextField JTextID;
    private javax.swing.JLabel Lable;
    private javax.swing.JTextField cardNumber;
    private javax.swing.JButton goBack;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextFirstName;
    private javax.swing.JTextField jTextLastName;
    private javax.swing.JTextField nameOnCard;
    private javax.swing.JButton placeOrder;
    // End of variables declaration//GEN-END:variables
}
